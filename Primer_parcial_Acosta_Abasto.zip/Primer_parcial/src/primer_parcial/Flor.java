
package primer_parcial;


public class Flor extends Planta {

    private Temporada_Florecimiento tempFlorecimiento;

    public Flor(Temporada_Florecimiento tempFlorecimiento, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.tempFlorecimiento = tempFlorecimiento;
    }
    
    @Override
    public String toString() {
        return "[Flor]" + "Nombre: " + nombre + "- Ubicacion: " + ubicacion + "- Clima: " + clima + "- Temporada Florecimiento: " + tempFlorecimiento;
    }
    
    private void validarTempFloreciento(String tempFloreciento){
        if (!"PRIMAVERA".equals(tempFloreciento) || !"VERANO".equals(tempFloreciento) || !"OTOÑO".equals(tempFloreciento) || !"INVIERNO".equals(tempFloreciento) ){
            throw new IllegalArgumentException("Error - Ingrese una temporada valida");
        }
    }
}
