
package primer_parcial;


public class Primer_parcial {

    
    public static void main(String[] args) {
        
        JardinBotanico j = new JardinBotanico();
                
        Arbol a1 = new Arbol(5, "Roble", "Norte", "Arido");
        Arbol a2 = new Arbol(5, "Roble", "Norte", "Arido");
        Arbusto arb1 = new Arbusto(5, "Tarajal", "Este", "Templado");
        Flor f1 = new Flor(Temporada_Florecimiento.INVIERNO, "Rosa", "Sur", "Tropical");
        
        try{
            j.agregarPlanta(a1);
            j.agregarPlanta(a2);
            j.agregarPlanta(arb1);
            j.agregarPlanta(f1);
        
        }catch(RuntimeException ex){
            System.out.println(ex.getMessage());
        }
        
        try{
            j.mostrarPlantas();
        
        }catch (IllegalArgumentException ex){
            System.out.println(ex.getMessage());
        }
        
        try{
            j.podarPlantas();
        
        }catch (IllegalArgumentException ex){
            System.out.println(ex.getMessage());
        }
        
        
    }
    
    
}
