
package primer_parcial;


public class Arbol extends Planta implements Podable {
    
    private double alturaMax;

    public Arbol(int alturaMax, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.alturaMax = alturaMax;
    }

    @Override
    public String toString() {
        return "[Arbol]" + "Nombre: " + nombre + "- Ubicacion: " + ubicacion + "- Clima: " + clima + "- Altura max: " + alturaMax;
    }
    
    private void validarAlturaMax(int alturaMax){
        if (alturaMax < 1){
            throw new IllegalArgumentException("La altura maxima no puede ser menor a 1 metro");
        }
    }
    
    @Override
    public void podar() {
        System.out.println("Arbol podado");
    }
    
    
}
