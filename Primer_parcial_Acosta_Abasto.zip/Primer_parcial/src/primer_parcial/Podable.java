
package primer_parcial;


public interface Podable {

    public abstract void podar(); 

}
