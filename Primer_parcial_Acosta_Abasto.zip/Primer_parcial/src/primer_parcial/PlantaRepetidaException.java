
package primer_parcial;


public class PlantaRepetidaException extends RuntimeException {
    
    public static final String MESSAGE = "Esta planta ya existe en el Jardin Botanico";
    
    public PlantaRepetidaException() {
        super(MESSAGE);
    }

}
