
package primer_parcial;

import java.util.Objects;

public abstract class Planta {
    protected String nombre;
    protected String ubicacion;
    protected String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    private void validarString(String string){
        if (string == null){
            throw new NullPointerException("Error, no se admiten null");
        }
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(o == null || getClass() != o.getClass()){
            return false;
        }
        Planta other = (Planta) o;

        return other.nombre.equals(this.nombre) &&
                other.ubicacion.equals(this.ubicacion);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }

}
