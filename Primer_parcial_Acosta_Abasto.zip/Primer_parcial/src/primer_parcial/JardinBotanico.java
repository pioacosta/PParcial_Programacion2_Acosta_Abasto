
package primer_parcial;

import java.util.ArrayList;

public class JardinBotanico {

    private ArrayList<Planta> plantas;
    
    public JardinBotanico(){
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta planta) {
        if (planta == null){
            throw new NullPointerException("Error, no se admiten null");
        }
        if (plantas.contains(planta)){
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
        System.out.println("Planta agregada exitosamente.");
    }
    
    public void mostrarPlantas(){
        if (plantas.isEmpty()){
            throw new IllegalArgumentException("No hay plantas");
        }
        
        else
            for (Planta planta : plantas){
                System.out.println(planta);
        }
    }
    
    public void podarPlantas(){
        if (plantas.isEmpty()){
            throw new IllegalArgumentException("No hay plantas para podar");
        }
        
        else{
         for (Planta planta : plantas){
             if (planta instanceof Podable p){
                 p.podar();
                 System.out.println("Planta podada");
             }
             else{
                 throw new IllegalArgumentException("Las flores no pueden podarse");
             }
         }   
        }
    }
}
