
package primer_parcial;


public enum Temporada_Florecimiento {

    PRIMAVERA, VERANO, OTONIO, INVIERNO
}
