
package primer_parcial;


public class Arbusto extends Planta implements Podable{

    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public String toString() {
        return "[Arbusto]" + "Nombre: " + nombre + "- Ubicacion: " + ubicacion + "- Clima: " + clima + "- Densidad follaje: " + densidadFollaje;
    }
    
    private void validarDensidadFollaje(int densidadFollaje){
        if (densidadFollaje < 1 || densidadFollaje > 10){
            throw new IllegalArgumentException("La densidad del follaje debe estar entre 1 y 10");
        }
    }
    
    @Override
    public void podar() {
        System.out.println("Arbusto podado");
    }
}
